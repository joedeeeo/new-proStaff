package com.prostaff.service.designation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDesignationApplicationTests {

	@Test
	void contextLoads() {
	}

}

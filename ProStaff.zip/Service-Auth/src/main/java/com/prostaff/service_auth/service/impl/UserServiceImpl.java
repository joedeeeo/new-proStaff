package com.prostaff.service_auth.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.prostaff.service_auth.domian.User;
import com.prostaff.service_auth.dto.LoginRequest;
import com.prostaff.service_auth.dto.LoginResponse;
import com.prostaff.service_auth.inter_service_communication.dto.AuthRequest;
import com.prostaff.service_auth.inter_service_communication.dto.EmployeeEmailWrapper;
import com.prostaff.service_auth.inter_service_communication.dto.NewUser;
import com.prostaff.service_auth.inter_service_communication.enums.Role;
import com.prostaff.service_auth.repository.UserRepository;
import com.prostaff.service_auth.service.UserService;
import com.prostaff.service_auth.utils.JwtUtils;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository db;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Override
	public Boolean addUser(NewUser newUser) {
		User entity = new User();
		
		if(db.existsById(newUser.getEmail())) return false;
		
		entity.setEmail(newUser.getEmail());
		entity.setPassword(newUser.getPassword());
		entity.setFullName(newUser.getFullName());
		entity.setOrganizationName(newUser.getOrganizationName());
		entity.setRole(Role.EMPLOYEE);
		
		db.save(entity);
		return true;
	}

	@Override
	public Boolean deleteUser(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return false;
		
		db.deleteById(employeeEmailWrapper.getEmployeeEmail());
		
		return true;
	}

	@Override
	public LoginResponse login(LoginRequest loginRequest) {
		
		if(!db.existsById(loginRequest.getEmail()) || !passwordEncoder.matches(loginRequest.getPassword(), db.findById(loginRequest.getEmail()).get().getPassword()))
		{
			return new LoginResponse("FAILED", null);
		}
		
		LoginResponse loginResponse = new LoginResponse(jwtUtils.generateToken(loginRequest.getEmail()), db.findById(loginRequest.getEmail()).get().getRole());
		return loginResponse;
	}

	@Override
	public Integer validate(AuthRequest authRequest) {
		
		String path = authRequest.getPath();
		System.err.println(path);
		String token = authRequest.getJwtToken();
		token = token.substring(7);
		
		List<String> employeeAccessiblePaths = List.of(
		   "/employee/get-employee-information",
		   "/employee/update-employee-profile-image",
		   "/team/get-employee-teams",
		   "/department/get-employee-department",
		   "/designation/get-employee-designation",
		   "/attendance/get-employee-attendance",
		   "/attendance/check-in",
		   "/attendance/check-out",
		   "/attendance/get-employee-attendance",
		   "/leave-request/get-employee-leave-request",
		   "/leave-request/create-request",
		   "/notification/get-emplyoyee-notifications"
		);
		
		try {
			
			String email = jwtUtils.extractUserName(token);
			
			if(!db.existsById(email) || jwtUtils.isTokenExpired(token)) return 1;
			User user = db.findById(email).get();
			if(user.getRole() == Role.ADMIN) return 0;
			
			// user is employee
			if(isValidEmployeePath(path, employeeAccessiblePaths)) return 0;
			return 2;
			
		} catch (Exception e) {return 1;}
	}

	@Override
	public Boolean isUserExist(EmployeeEmailWrapper employeeEmailWrapper) {
		return db.existsById(employeeEmailWrapper.getEmployeeEmail());
	}

	@Override
	public String getUserOrganization(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return "";
		return db.findById(employeeEmailWrapper.getEmployeeEmail()).get().getOrganizationName();
	}

	@Override
	public String getFullName(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return "NO SUCH USER EXIST";
		return db.findById(employeeEmailWrapper.getEmployeeEmail()).get().getFullName();
	}
	
	private boolean isValidEmployeePath(String path, List<String> allowedPaths)
	{
		for(String allowedPath : allowedPaths)
		{
			if(path.contains(allowedPath)) return true;
		}
		return false;
	}
	
}

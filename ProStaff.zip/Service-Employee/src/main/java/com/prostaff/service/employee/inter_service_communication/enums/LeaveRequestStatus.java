package com.prostaff.service.employee.inter_service_communication.enums;

public enum LeaveRequestStatus {
	ACCEPTED, REJECTED, PENDING
}

package com.prostaff.service.department.inter_service_communication.enums;

public enum LeaveRequestType {
	PAID, UNPAID, SICK
}

package com.prostaff.service.team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}

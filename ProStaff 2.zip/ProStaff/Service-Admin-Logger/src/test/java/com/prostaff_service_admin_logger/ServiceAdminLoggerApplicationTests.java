package com.prostaff_service_admin_logger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAdminLoggerApplicationTests {

	@Test
	void contextLoads() {
	}

}

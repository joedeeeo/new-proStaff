package com.prostaff.service_admin_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAdminServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
